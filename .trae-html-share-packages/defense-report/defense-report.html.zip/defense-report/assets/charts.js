(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  var palette = [accent, accent2, '#7a6bb5', '#9c8ccf', '#c5b9e0'];

  // --- Chart: 项目进度 ---
  var c1 = echarts.init(document.getElementById('chart-progress'), null, { renderer: 'svg' });
  c1.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true },
    legend: { data: ['任务数', '已完成'], textStyle: { color: muted }, top: 0 },
    grid: { left: 60, right: 30, top: 50, bottom: 40 },
    xAxis: {
      type: 'category',
      data: ['Phase 0\n公共地基', 'Phase 1\n业务闭环', 'Phase 2\n联调'],
      axisLabel: { color: muted, fontSize: 13, lineHeight: 18 },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'value',
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [
      {
        name: '任务数', type: 'bar',
        data: [10, 6, 4],
        itemStyle: { color: bg2, borderRadius: [4, 4, 0, 0] },
        barWidth: 28
      },
      {
        name: '已完成', type: 'bar',
        data: [10, 3, 0],
        itemStyle: { color: accent, borderRadius: [4, 4, 0, 0] },
        barWidth: 28,
        label: { show: true, position: 'top', color: ink, fontWeight: 600 }
      }
    ]
  });
  window.addEventListener('resize', function() { c1.resize(); });

  // --- Chart: 模块分布 ---
  var c2 = echarts.init(document.getElementById('chart-modules'), null, { renderer: 'svg' });
  c2.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    legend: { orient: 'vertical', right: 20, top: 'center', textStyle: { color: ink, fontSize: 13 } },
    series: [{
      type: 'pie',
      radius: ['42%', '68%'],
      center: ['35%', '50%'],
      itemStyle: { borderColor: bg2, borderWidth: 2, borderRadius: 4 },
      label: { show: true, formatter: '{d}%', color: ink, fontWeight: 600, fontSize: 14 },
      labelLine: { show: false },
      data: [
        { value: 22, name: 'M0 公共基建', itemStyle: { color: '#5a50b8' } },
        { value: 20, name: 'M1 客户+研判', itemStyle: { color: '#2d2b73' } },
        { value: 18, name: 'M2 客服 Agent', itemStyle: { color: '#7a6bb5' } },
        { value: 16, name: 'M3 员工模块', itemStyle: { color: '#9c8ccf' } },
        { value: 14, name: 'M4 学生模块', itemStyle: { color: '#c5b9e0' } },
        { value: 10, name: 'M5 智能报告', itemStyle: { color: accent2 } }
      ]
    }]
  });
  window.addEventListener('resize', function() { c2.resize(); });

  // --- Chart: 测试覆盖 ---
  var c3 = echarts.init(document.getElementById('chart-tests'), null, { renderer: 'svg' });
  c3.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: 160, right: 40, top: 20, bottom: 30 },
    xAxis: {
      type: 'value', max: 35,
      axisLabel: { color: muted },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    yAxis: {
      type: 'category',
      data: ['pytest 后端单元', 'verify_all 结构校验', '前端 npm build', 'compileall 语法编译', 'E2E 端到端'],
      axisLabel: { color: ink, fontWeight: 500 },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: [
        { value: 170, itemStyle: { color: accent } },
        { value: 29, itemStyle: { color: '#67c23a' } },
        { value: 1, itemStyle: { color: '#409eff' } },
        { value: 1, itemStyle: { color: '#409eff' } },
        { value: 80, itemStyle: { color: '#e6a23c' } }
      ],
      barWidth: 22,
      itemStyle: { borderRadius: [0, 4, 4, 0] },
      label: { show: true, position: 'right', color: ink, fontWeight: 600 }
    }]
  });
  window.addEventListener('resize', function() { c3.resize(); });

  // --- Chart: 技术栈 ---
  var c4 = echarts.init(document.getElementById('chart-stack'), null, { renderer: 'svg' });
  c4.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    grid: { left: 20, right: 20, top: 10, bottom: 10, containLabel: true },
    radar: {
      center: ['50%', '50%'], radius: '68%',
      indicator: [
        { name: '后端框架', max: 10 }, { name: '异步ORM', max: 10 },
        { name: '数据库', max: 10 }, { name: '前端框架', max: 10 },
        { name: '状态管理', max: 10 }, { name: 'AI 编排', max: 10 }
      ],
      axisName: { color: ink, fontWeight: 500, fontSize: 12 },
      splitArea: { areaStyle: { color: ['rgba(90,80,184,0.03)', 'rgba(90,80,184,0.06)'] } },
      splitLine: { lineStyle: { color: rule } },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'radar',
      data: [{
        value: [9, 9, 8, 9, 8, 9],
        name: '项目覆盖',
        areaStyle: { color: 'rgba(90,80,184,0.25)' },
        lineStyle: { color: accent, width: 2 },
        itemStyle: { color: accent }
      }]
    }]
  });
  window.addEventListener('resize', function() { c4.resize(); });

  // --- Chart: 问题时间线 ---
  var c5 = echarts.init(document.getElementById('chart-timeline'), null, { renderer: 'svg' });
  c5.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: 80, right: 30, top: 30, bottom: 60 },
    xAxis: {
      type: 'category',
      data: ['Phase 0\n地基搭建', 'Phase 1\n并行开发', 'Phase 1.5\n合并联调', 'Phase 1.8\nDify 接入', 'Phase 1.9\n多线同步', 'Phase 2\n答辩交付'],
      axisLabel: { color: muted, fontSize: 11, lineHeight: 16 },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'value', name: '问题数', nameTextStyle: { color: muted },
      axisLabel: { color: muted },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [{
      type: 'line', smooth: true,
      data: [8, 15, 18, 12, 9, 3],
      lineStyle: { color: accent, width: 3 },
      itemStyle: { color: accent, borderColor: '#fff', borderWidth: 2 },
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [{ offset: 0, color: 'rgba(90,80,184,0.35)' }, { offset: 1, color: 'rgba(90,80,184,0.02)' }] } },
      label: { show: true, color: ink, fontWeight: 600, position: 'top' }
    }]
  });
  window.addEventListener('resize', function() { c5.resize(); });
})();
